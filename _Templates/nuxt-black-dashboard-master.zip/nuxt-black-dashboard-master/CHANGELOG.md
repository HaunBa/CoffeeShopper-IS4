# Changelog

## [1.0.0] 2020-10-01

### Stable Original Release
